// ==========================================================================
// SolidW — Public Booking Page Logic
// ==========================================================================

import { supabase } from "/assets/js/supabaseClient.js";
import { getSlug } from "/assets/js/routing.js";

const DAY_LABELS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const loadingState = document.getElementById("loadingState");
const notFoundState = document.getElementById("notFoundState");
const pageContent = document.getElementById("pageContent");

const publicHero = document.getElementById("publicHero");
const businessLogo = document.getElementById("businessLogo");
const businessName = document.getElementById("businessName");
const businessAddress = document.getElementById("businessAddress");
const businessDescription = document.getElementById("businessDescription");
const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");

const whatsappLink = document.getElementById("whatsappLink");
const telegramLink = document.getElementById("telegramLink");
const phoneLink = document.getElementById("phoneLink");
const websiteLink = document.getElementById("websiteLink");
const instagramLink = document.getElementById("instagramLink");
const tiktokLink = document.getElementById("tiktokLink");

const galleryGrid = document.getElementById("galleryGrid");
const galleryEmpty = document.getElementById("galleryEmpty");
const servicesGrid = document.getElementById("servicesGrid");
const servicesEmpty = document.getElementById("servicesEmpty");
const hoursTableBody = document.getElementById("hoursTableBody");

const bookingForm = document.getElementById("bookingForm");
const bookingClosedNotice = document.getElementById("bookingClosedNotice");
const bookingSuccess = document.getElementById("bookingSuccess");
const bookingError = document.getElementById("bookingError");
const bookingSubmitBtn = document.getElementById("bookingSubmitBtn");
const bookingSubmitLabel = document.getElementById("bookingSubmitLabel");
const bookingDateInput = document.getElementById("bookingDate");
const bookingTimeInput = document.getElementById("bookingTime");

const lightboxOverlay = document.getElementById("lightboxOverlay");
const lightboxImage = document.getElementById("lightboxImage");
const lightboxClose = document.getElementById("lightboxClose");

let business = null;
let hoursByDay = {};

// ---- Local-time helpers -------------------------------------------------
// Using toISOString()/getters that go through UTC will silently shift the
// "today" date for anyone not at UTC+0. These build date/time strings from
// the browser's LOCAL clock instead.
function localDateStr(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function localTimeStr(d = new Date()) {
  const h = String(d.getHours()).padStart(2, "0");
  const min = String(d.getMinutes()).padStart(2, "0");
  return `${h}:${min}`;
}

async function init() {
  const slug = getSlug();

  if (!slug) {
    showNotFound();
    return;
  }

  const { data, error } = await supabase
    .from("businesses")
    .select("*")
    .eq("slug", slug)
    .single();

  if (error || !data) {
    showNotFound();
    return;
  }

  business = data;

  if (!business.published) {
    showPreviewBanner();
  }

  const [{ data: gallery }, { data: services }, { data: hours }] = await Promise.all([
    supabase.from("gallery_images").select("id, url").eq("business_id", business.id).order("sort_order"),
    supabase.from("services").select("id, name, price, description").eq("business_id", business.id).order("sort_order"),
    supabase.from("opening_hours").select("day_of_week, open_time, close_time, closed").eq("business_id", business.id),
  ]);

  hoursByDay = {};
  for (const h of hours || []) hoursByDay[h.day_of_week] = h;

  render();
  renderGallery(gallery || []);
  renderServices(services || []);
  renderHours();
  logEvent("page_view");

  loadingState.style.display = "none";
  pageContent.style.display = "block";
}

function showPreviewBanner() {
  const banner = document.createElement("div");
  banner.style.cssText =
    "background:var(--color-ink);color:var(--color-paper);text-align:center;padding:0.75rem 1rem;font-size:0.875rem;position:sticky;top:0;z-index:500;";
  banner.textContent = "Preview mode — this page isn't published yet, so customers can't see it.";
  document.body.prepend(banner);
}

function showNotFound() {
  loadingState.style.display = "none";
  notFoundState.style.display = "block";
}

// ---- Live open/closed status, driven by today's actual hours ------------
function getLiveStatus() {
  if (!business.accepting_bookings) {
    return { state: "closed", label: "Not accepting online bookings" };
  }

  const todayHours = hoursByDay[new Date().getDay()];

  if (!todayHours || todayHours.closed || !todayHours.open_time || !todayHours.close_time) {
    return { state: "closed", label: "Closed today" };
  }

  const now = localTimeStr();
  const open = todayHours.open_time.slice(0, 5);
  const close = todayHours.close_time.slice(0, 5);

  if (now < open) return { state: "opening-soon", label: `Opens at ${open} today` };
  if (now >= close) return { state: "closed", label: "Closed for today" };
  return { state: "open", label: `Open now · closes ${close}` };
}

function render() {
  document.getElementById("pageTitle").textContent = `${business.name} · SolidW`;
  document.getElementById("pageDescription").content = business.description || `Book with ${business.name}.`;

  if (business.cover_url) {
    publicHero.style.backgroundImage = `url('${business.cover_url}')`;
    publicHero.style.display = "block";
  } else {
    publicHero.style.display = "none";
    document.querySelector(".public-header-card").classList.add("no-cover");
  }

  if (business.logo_url) {
    businessLogo.src = business.logo_url;
    businessLogo.style.display = "block";
  }

  businessName.textContent = business.name;
  businessAddress.textContent = business.address || "";
  businessDescription.textContent = business.description || "No description provided yet.";

  const status = getLiveStatus();
  statusDot.classList.remove("closed", "opening-soon");
  if (status.state === "open") {
    // default dot color = open
  } else if (status.state === "opening-soon") {
    statusDot.classList.add("opening-soon");
  } else {
    statusDot.classList.add("closed");
  }
  statusText.textContent = status.label;

  if (!business.accepting_bookings) {
    bookingClosedNotice.style.display = "block";
    bookingForm.style.display = "none";
  }

  if (business.whatsapp) {
    whatsappLink.href = `https://wa.me/${business.whatsapp.replace(/[^0-9]/g, "")}`;
    whatsappLink.style.display = "inline-flex";
    whatsappLink.addEventListener("click", () => logEvent("whatsapp_click"));
  }
  if (business.telegram) {
    telegramLink.href = `https://t.me/${business.telegram.replace(/^@/, "")}`;
    telegramLink.style.display = "inline-flex";
    telegramLink.addEventListener("click", () => logEvent("telegram_click"));
  }
  if (business.phone) {
    phoneLink.href = `tel:${business.phone}`;
    phoneLink.style.display = "inline-flex";
  }
  if (business.website) {
    websiteLink.href = business.website;
    websiteLink.style.display = "inline-flex";
  }
  if (business.instagram) {
    instagramLink.href = `https://instagram.com/${business.instagram.replace(/^@/, "")}`;
    instagramLink.style.display = "inline-flex";
    instagramLink.addEventListener("click", () => logEvent("instagram_click"));
  }
  if (business.tiktok) {
    tiktokLink.href = `https://tiktok.com/@${business.tiktok.replace(/^@/, "")}`;
    tiktokLink.style.display = "inline-flex";
    tiktokLink.addEventListener("click", () => logEvent("tiktok_click"));
  }

  // Local (not UTC) "today", so the date picker never blocks out the
  // customer's actual today near midnight.
  bookingDateInput.min = localDateStr();
  updateMinTimeForSelectedDate();
}

// If the customer picks today's date, don't let them pick a time that's
// already passed. For any future date, no time restriction.
function updateMinTimeForSelectedDate() {
  if (bookingDateInput.value === localDateStr()) {
    bookingTimeInput.min = localTimeStr();
  } else {
    bookingTimeInput.removeAttribute("min");
  }
}
bookingDateInput.addEventListener("change", updateMinTimeForSelectedDate);

function renderGallery(images) {
  galleryGrid.innerHTML = "";
  if (images.length === 0) {
    galleryEmpty.style.display = "block";
    return;
  }
  galleryEmpty.style.display = "none";

  for (const img of images) {
    const el = document.createElement("img");
    el.src = img.url;
    el.alt = business.name;
    el.addEventListener("click", () => openLightbox(img.url));
    galleryGrid.appendChild(el);
  }
}

function openLightbox(url) {
  lightboxImage.src = url;
  lightboxOverlay.style.display = "flex";
}
lightboxClose.addEventListener("click", () => (lightboxOverlay.style.display = "none"));
lightboxOverlay.addEventListener("click", (e) => {
  if (e.target === lightboxOverlay) lightboxOverlay.style.display = "none";
});

function renderServices(services) {
  servicesGrid.innerHTML = "";
  if (services.length === 0) {
    servicesEmpty.style.display = "block";
    return;
  }
  servicesEmpty.style.display = "none";

  for (const svc of services) {
    const card = document.createElement("div");
    card.className = "card public-service-card";
    card.innerHTML = `
      <div>
        <div class="name">${escapeHtml(svc.name)}</div>
        ${svc.description ? `<div class="text-muted" style="font-size: var(--fs-sm);">${escapeHtml(svc.description)}</div>` : ""}
      </div>
      <div class="price">$${Number(svc.price).toFixed(2)}</div>
    `;
    servicesGrid.appendChild(card);
  }
}

function renderHours() {
  const todayDow = new Date().getDay();

  hoursTableBody.innerHTML = "";
  for (let d = 0; d < 7; d++) {
    const h = hoursByDay[d];
    const isToday = d === todayDow;
    const tr = document.createElement("tr");
    const timeText =
      !h || h.closed || !h.open_time || !h.close_time
        ? "Closed"
        : `${h.open_time.slice(0, 5)} – ${h.close_time.slice(0, 5)}`;
    tr.innerHTML = `
      <td class="${isToday ? "today" : ""}">${DAY_LABELS[d]}${isToday ? " · Today" : ""}</td>
      <td class="${isToday ? "today" : ""}">${timeText}</td>
    `;
    hoursTableBody.appendChild(tr);
  }
}

document.querySelectorAll(".public-tab").forEach((tab) => {
  tab.addEventListener("click", (e) => {
    e.preventDefault();
    const target = tab.dataset.tab;

    document.querySelectorAll(".public-tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");

    document.querySelectorAll(".tab-panel").forEach((panel) => {
      panel.style.display = panel.id === `${target}-panel` ? "block" : "none";
    });
  });
});

bookingForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  bookingError.style.display = "none";
  bookingSuccess.style.display = "none";

  const customerName = document.getElementById("customerName").value.trim();
  const customerPhone = document.getElementById("customerPhone").value.trim();
  const date = bookingDateInput.value;
  const time = bookingTimeInput.value;
  const notes = document.getElementById("bookingNotes").value.trim();

  if (!customerName || !customerPhone || !date || !time) {
    bookingError.textContent = "Please fill in all required fields.";
    bookingError.style.display = "block";
    return;
  }

  if (date === localDateStr() && time < localTimeStr()) {
    bookingError.textContent = "That time has already passed today — pick a later time.";
    bookingError.style.display = "block";
    return;
  }

  bookingSubmitBtn.disabled = true;
  bookingSubmitLabel.innerHTML = '<span class="spinner"></span> Booking…';

  const { error } = await supabase.from("reservations").insert({
    business_id: business.id,
    customer_name: customerName,
    phone: customerPhone,
    date,
    time,
    notes: notes || null,
    status: "pending",
  });

  bookingSubmitBtn.disabled = false;
  bookingSubmitLabel.textContent = "Book Now";

  if (error) {
    bookingError.textContent = error.message || "Could not submit your booking. Please try again.";
    bookingError.style.display = "block";
    return;
  }

  bookingSuccess.textContent = "Your reservation request has been sent!";
  bookingSuccess.style.display = "block";
  bookingForm.reset();
  bookingDateInput.min = localDateStr();
  logEvent("reservation_submit");
});

async function logEvent(eventType) {
  if (!business) return;
  await supabase.from("events").insert({
    business_id: business.id,
    event_type: eventType,
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

init();
